// app.js
const getRandomGreeting = require('./greeting');

randomGreeting.text=getRandomGreeting();